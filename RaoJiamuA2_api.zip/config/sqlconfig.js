const sqlconfig = {
    host: '127.0.0.1',  // 连接地址
    user: 'root',    //用户名
    password: 'root',  //密码
    port:  3306 ,   //端口号
    database: 'crowdfunding_db',   //数据库名
    connectTimeout: 5000 // 连接超时
  }
module.exports = sqlconfig
