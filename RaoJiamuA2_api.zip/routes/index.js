const express = require("express");
// 注册路由 
const router = express.Router(); 
//导入数据库
const db = require('../config/crowdfunding_db');

router.get('/item', (req, res) => {
    let queries = req.query.keyword;
    let sql = `SELECT * FROM market_data WHERE is_remove = '0' AND fang_wei = '${queries}'`
	db.querySql(sql) .then(data => {
		res.json({ 
			msg: '查询成功！', 
			data: data 
		})
	})
})

// 从数据库中检索所有活动的筹款活动
router.get('/FUNDRAISER_List', (req, res) => {
    let ORGANIZER = req.query.ORGANIZER ? req.query.ORGANIZER : "";
    let CITY = req.query.CITY ? req.query.CITY : "";
    let CATEGORY_ID = req.query.CATEGORY_ID ? req.query.CATEGORY_ID : "";
    let sql = `SELECT a.*, b.name as NAME FROM FUNDRAISER a LEFT JOIN CATEGORY b ON b.CATEGORY_ID = a.CATEGORY_ID WHERE a.ORGANIZER LIKE '%${ORGANIZER}%' AND a.CITY LIKE '%${CITY}%' AND a.CATEGORY_ID LIKE '%${CATEGORY_ID}%'`
    console.log(sql)
    db.querySql(sql).then(data => {
        res.json({ 
            msg: '查询成功！', 
            data: data,
        })
    })
})

//从数据库中检索类别
router.get('/CATEGORY_List', (req, res) => {
    let sql = `SELECT * FROM CATEGORY`
    console.log(sql)
    db.querySql(sql).then(data => {
        res.json({ 
            msg: '查询成功！', 
            data: data,
        })
    })
})

//从数据库中查询筹款人信息
router.get('/FUNDRAISER_Item', (req, res) => {
    let FUNDRAISER_ID = req.query.FUNDRAISER_ID;
    let sql = `SELECT a.*, b.name as NAME FROM FUNDRAISER a LEFT JOIN CATEGORY b ON b.CATEGORY_ID = a.CATEGORY_ID WHERE a.FUNDRAISER_ID = '${FUNDRAISER_ID}'`
    console.log(sql)
	db.querySql(sql) .then(data => {
		res.json({ 
			msg: '查询成功！', 
			data: data 
		})
	})
})


module.exports = router;