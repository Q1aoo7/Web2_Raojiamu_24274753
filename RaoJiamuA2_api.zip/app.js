// 导入express
const express = require("express");
const routes = require('./routes'); //导入自定义路由文件，创建模块化路由
const bodyParser = require('body-parser'); // 引入body-parser模块
const path = require('path');
// 解决跨域
const cors = require('cors');
const app = express();

// 解决跨域问题
app.use(cors());
 
app.use(express.static('view'));

app.use(express.static(path.join(__dirname, '/public')));

app.use(bodyParser.json()); // 解析json数据格式
app.use(bodyParser.urlencoded({extended: true})); // 解析form表单提交的数据application/x-www-form-urlencoded
app.use('/', routes);
 
// 启动服务，并监听端口
app.listen(1000, () => {
  console.log("服务器启动了");
});